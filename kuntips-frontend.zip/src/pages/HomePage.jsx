export default function HomePage() {
  return (
    <main className="card">
      <h1>KunTips</h1>
      <p className="text-muted">
        Støtt favorittene dine – trygt, enkelt og diskret.
      </p>
      <p>
        Denne siden blir landingssiden vår senere. Akkurat nå kan du teste en
        eksempelprofil ved å gå til <code>/u/mia</code>.
      </p>
    </main>
  );
}
